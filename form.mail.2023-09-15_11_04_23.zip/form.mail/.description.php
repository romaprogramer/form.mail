<? (!defined(B_PROLOG_INCLUDED) || B_PROLOG_INCLUDED !==true) or exit; ?>
<? 
    $arComponentDescription = array(
        "NAME" => "Форма заявки",
        "SORT" => 20,
        "PATH" => array(
            "ID" => "my_components",
            "NAME" => "Мои компоненты",
            "SORT" => 2000,
            )
        );

