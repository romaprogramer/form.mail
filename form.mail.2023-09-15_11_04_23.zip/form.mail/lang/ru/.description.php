<? 
    $MESS['FORM_NAME'] = "Форма заявки";